<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\Week;



class WeekSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $date = date('Y-m-d', strtotime('2021-10-18'));
        $users = User::all();
        $uid = 0;
        for ($x=0; $x<100; $x++) {
            if ($uid < (count($users) - 1)) $uid += 1;
            Week::create([
                'user_id' => $users[$uid]->id,
                'day' => $date
            ]);
            $date = date("Y-m-d",strtotime(date("Y-m-d", strtotime($date)) . " +1 week"));
        }

    }
}
