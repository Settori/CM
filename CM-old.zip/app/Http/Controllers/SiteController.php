<?php

namespace App\Http\Controllers;
use Inertia\Inertia;

use Illuminate\Http\Request;

class SiteController extends Controller
{
    public function main_view() {
        return Inertia::render('Main', []);
    }

    public function chat_view() {
        return Inertia::render('Chat', []);
    }
}
