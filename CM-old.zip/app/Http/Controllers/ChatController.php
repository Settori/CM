<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Events\Test;
use Auth;


class ChatController extends Controller
{
    public function sendMessage() {
        Test::dispatch('3', 'qweqwe');
        return true;
    }
}
