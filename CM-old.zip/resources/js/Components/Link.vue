<template>
    <div>qwe</div>

</template>

<script>
    // import { Link } from '@inertiajs/inertia-vue3'
    export default {
        components: {
            // Link
        },
        props: {
            href: [String]
        },
        setup(props) {

        }
    }
</script>
