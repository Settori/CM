<template>
    <div class="w-56 px-4 bg-gray-800 text-white relative h-screen overflow-y-auto overscroll-x-none flex flex-col items-center">

        <div class="w-32 h-32 p-1 rounded-full flex justify-center items-center bg-pink-500 mt-8 mb-4">
            <img
            src="/img/paluszek.png"
            class="max-w-32 max-h-32 rounded-full "
            >
        </div>

        <div class="flex flex-col text-left w-full divide-y divide-gray-600">
            <Link
            v-for="m in menuItems"
            :key="m"
            class="py-2"
            :href="m.route"
            >
            {{m.name}}
            </Link>
        </div>
    </div>
</template>

<script>
import { onMounted, onUnmounted, ref } from 'vue'
import { Link } from '@inertiajs/inertia-vue3'

export default {
    components: {
        Link
    },
    props: {

    },
    setup() {
        const menuItems = ref([
            {
                icon: '',
                name: 'Pulpit',
                route: route('main')
            },
            {
                icon: '',
                name: 'Czat',
                route: route('chat')
            },
            {
                icon: '',
                name: 'Ustawienia',
                route: '#'
            },
        ])

        return {
            menuItems
        }
    },
}
</script>
