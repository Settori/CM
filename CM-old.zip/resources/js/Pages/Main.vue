<template>
    <MainLayout>
        qwe
    </MainLayout>
</template>


<script>
import MainLayout from '@/Layouts/Main';
import {onMounted} from 'vue';


export default {
    components: {
        MainLayout,
    },
    props: {
        canLogin: Boolean,
        canRegister: Boolean,
        laravelVersion: String,
        phpVersion: String,
    },
    setup(props) {
        onMounted(() => {
            console.log("yea")
            Echo.channel('testchannel')
            .listen('.message.created', (e) => {

            });
        })
    }
}
</script>
