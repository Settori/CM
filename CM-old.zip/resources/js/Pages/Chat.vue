<template>
    <MainLayout>
        Czat

        <div
        class="bg-pink-700 text-white px-4 py-1 rounded-md"
        @click="sendMessage()"
        >
            Send
        </div>
    </MainLayout>
</template>


<script>
import MainLayout from '@/Layouts/Main';
import {onMounted} from 'vue';
import { Inertia } from '@inertiajs/inertia';


export default {
    components: {
        MainLayout,
    },
    props: {
        canLogin: Boolean,
        canRegister: Boolean,
        laravelVersion: String,
        phpVersion: String,
    },
    setup(props) {
        const sendMessage = () => {
            Inertia.post(route('send.message'))
        }
        onMounted(() => {
            console.log("yea")
            Echo.channel('testchannel')
            .listen('.message.created', (e) => {

            });
        })
        return {
            sendMessage
        }
    }
}
</script>
